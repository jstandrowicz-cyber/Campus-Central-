"""Quick demo + sanity test: python test_demo.py"""
import os
os.environ["FREEFOOD_DB"] = "demo.db"
if os.path.exists("demo.db"):
    os.remove("demo.db")

from app import save, upcoming
from classifier import classify

POSTS = [
    ("Cooking Club", "Join us Thursday 6pm in the Campus Center! Free pizza and boba for all attendees 🍕", True),
    ("Debate Society", "Weekly meeting, we'll be practicing rebuttals. All majors welcome.", False),
    ("Robotics Club", "General body meeting. Snacks and drinks provided! Free t-shirts while supplies last.", True),
    ("Greek Life", "Bake sale fundraiser, cookies $3 each, cash only", False),
    ("Hillel", "Shabbat dinner this Friday, come hungry, complimentary dinner for students", True),
    ("Volunteer Org", "Food drive this week, bring canned goods to donate", False),
]
ok = 0
for org, text, expect in POSTS:
    r = classify(text)
    flag = "OK " if r["has_free_food"] == expect else "BAD"
    ok += r["has_free_food"] == expect
    print(f"{flag} score={r['score']:.2f} {org}: {text[:55]}")
    if r["has_free_food"]:
        save({"org": org, "title": text[:60], "text": text, "start": "2026-11-13T18:00:00"})
print(f"\n{ok}/{len(POSTS)} correct; {len(upcoming())} events stored")
