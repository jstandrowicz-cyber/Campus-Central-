# FreeFood@UMass

Finds free food and free stuff from campus clubs and shows it to students in one feed.

## Run it
```
pip install flask
python test_demo.py          # sanity check on sample posts
python app.py                # open http://localhost:5000
```
Optional: `pip install anthropic` and set `ANTHROPIC_API_KEY` so Claude double-checks borderline posts.

## How it works
1. **sources.py** pulls posts and events from iCal feeds, RSS/Atom feeds, and Instagram's official Graph API (clubs that opt in).
2. **classifier.py** scores each post for free food/stuff (keywords + "free/provided" cues, minus signals like "bake sale" or "food drive"). Borderline posts go to Claude.
3. **app.py** stores matches in SQLite and serves the student feed (`/`), a JSON API (`/api/events`), a student submission form (`/submit`), and a crawl trigger (`POST /refresh`).

Copy `sources.example.json` to `sources.json` and list the real club feeds you find.

## Data-source note
Scraping Instagram/Facebook/X directly breaks their terms of service and tends to get blocked. For the pitch, present the sourcing as: official feeds and APIs, club opt-in, forwarded club emails, and student crowdsourcing.

## Next steps
- Push notifications / email digest ("free food near you in the next 2 hours")
- Club dashboard so orgs can post their own free-food events
- Dietary tags (vegan, halal, kosher) and a "still has food?" report button
- Scheduled refresh (cron) and deployment
