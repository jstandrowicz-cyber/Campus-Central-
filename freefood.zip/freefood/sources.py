"""Source adapters. Each returns a list of dicts:
{source, org, title, text, url, start (ISO string or None), location}

Compliance note: Instagram/Facebook/X terms forbid unauthorized scraping.
Prefer (in this order): official calendar/RSS/iCal feeds, official APIs with
club opt-in, club email newsletters forwarded to an inbox, and student submissions.
"""
import re
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime

UA = {"User-Agent": "UMassFreeFoodFinder/0.1 (student project)"}


def _get(url: str, timeout=15) -> str:
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


# ---------- iCal ----------
def _unfold(ics: str) -> list[str]:
    out = []
    for line in ics.replace("\r\n", "\n").split("\n"):
        if line[:1] in (" ", "\t") and out:
            out[-1] += line[1:]
        else:
            out.append(line)
    return out


def _ics_date(val: str):
    m = re.match(r"(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2}))?", val)
    if not m:
        return None
    y, mo, d, h, mi, s = [int(x) if x else 0 for x in m.groups()]
    return datetime(y, mo, d, h, mi, s).isoformat()


def parse_ics(ics: str, org: str, source="ical"):
    events, cur = [], None
    for line in _unfold(ics):
        if line == "BEGIN:VEVENT":
            cur = {}
        elif line == "END:VEVENT" and cur is not None:
            events.append({
                "source": source, "org": org,
                "title": cur.get("SUMMARY", "").replace("\\,", ","),
                "text": (cur.get("SUMMARY", "") + ". " + cur.get("DESCRIPTION", ""))
                .replace("\\n", " ").replace("\\,", ","),
                "url": cur.get("URL", ""),
                "start": _ics_date(cur.get("DTSTART", "")),
                "location": cur.get("LOCATION", "").replace("\\,", ","),
            })
            cur = None
        elif cur is not None and ":" in line:
            k, v = line.split(":", 1)
            cur[k.split(";")[0]] = v
    return events


def fetch_ical(url: str, org: str):
    return parse_ics(_get(url), org)


# ---------- RSS / Atom ----------
def parse_feed(xml_text: str, org: str, source="rss"):
    root = ET.fromstring(xml_text)
    items = []
    for it in root.iter():
        tag = it.tag.split("}")[-1]
        if tag not in ("item", "entry"):
            continue
        g = lambda n: next((c.text or "" for c in it if c.tag.split("}")[-1] == n), "")
        link = g("link")
        if not link:
            for c in it:
                if c.tag.split("}")[-1] == "link":
                    link = c.attrib.get("href", "")
        body = re.sub(r"<[^>]+>", " ", g("description") or g("summary") or g("content"))
        items.append({
            "source": source, "org": org, "title": g("title"),
            "text": f"{g('title')}. {body}", "url": link, "start": None, "location": "",
        })
    return items


def fetch_feed(url: str, org: str):
    return parse_feed(_get(url), org)


# ---------- Instagram via official Graph API (opt-in clubs only) ----------
def fetch_instagram_graph(ig_user_id: str, token: str, org: str):
    """Works only for Business/Creator accounts that have granted your app access."""
    import json
    url = (f"https://graph.facebook.com/v19.0/{ig_user_id}/media"
           f"?fields=caption,permalink,timestamp&access_token={token}")
    data = json.loads(_get(url))
    return [{
        "source": "instagram", "org": org, "title": (p.get("caption") or "")[:70],
        "text": p.get("caption") or "", "url": p.get("permalink", ""),
        "start": None, "location": "",
    } for p in data.get("data", [])]


def load_all(config: dict):
    """config = {'ical': [{url, org}], 'rss': [...], 'instagram': [...]}"""
    posts, errors = [], []
    for kind, fn in (("ical", fetch_ical), ("rss", fetch_feed)):
        for s in config.get(kind, []):
            try:
                posts += fn(s["url"], s["org"])
            except Exception as e:
                errors.append(f"{s['org']}: {e}")
    for s in config.get("instagram", []):
        try:
            posts += fetch_instagram_graph(s["user_id"], s["token"], s["org"])
        except Exception as e:
            errors.append(f"{s['org']}: {e}")
    return posts, errors
