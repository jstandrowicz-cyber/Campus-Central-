"""Decides whether a post/event announces free food or free stuff.

Two layers:
1. Fast rule-based scorer (no API key needed).
2. Optional Claude pass for ambiguous posts (set ANTHROPIC_API_KEY).
"""
import json
import os
import re

FOOD = [
    "pizza", "donut", "doughnut", "bagel", "cookie", "snack", "boba", "bubble tea",
    "taco", "burrito", "chipotle", "dinner", "lunch", "breakfast", "brunch", "refreshment",
    "coffee", "cider", "ice cream", "cake", "cupcake", "wings", "sandwich", "sushi",
    "dumpling", "pasta", "food", "treats", "candy", "pancake", "waffle", "hot chocolate",
    "empanada", "samosa", "curry", "mochi", "popcorn", "fruit", "catering", "cater",
]
FREE_STUFF = [
    "t-shirt", "tshirt", "tee", "swag", "merch", "tote", "sticker", "giveaway",
    "raffle", "prizes", "plushie", "hoodie", "water bottle", "tote bag",
]
FREE_CUES = [
    r"free", r"complimentary", r"on us", r"provided", r"will be served", r"served",
    r"come hungry", r"snacks? (?:and|&) drinks", r"refreshments", r"while supplies last",
    r"bring your appetite", r"food (?:will be|is) (?:available|provided)",
]
NEGATIVES = [
    r"no (?:free )?food", r"food drive", r"food pantry donation", r"not free",
    r"bring (?:your own|canned)", r"\$\d+ (?:ticket|entry|cover)", r"cash only",
    r"fundraiser", r"bake sale", r"sold? ",
]


def _find(words, text):
    return sorted({w for w in words if re.search(r"\b" + re.escape(w), text)})


def rule_score(text: str) -> dict:
    t = text.lower()
    foods = _find(FOOD, t)
    stuff = _find(FREE_STUFF, t)
    cue = any(re.search(c, t) for c in FREE_CUES)
    neg = any(re.search(n, t) for n in NEGATIVES)

    score = 0.0
    if re.search(r"free\s+(?:\w+\s+){0,3}(?:" + "|".join(map(re.escape, FOOD)) + ")", t):
        score += 0.7
    elif foods and cue:
        score += 0.5
    elif foods:
        score += 0.2
    if stuff and cue:
        score += 0.35
    if re.search(r"free food", t):
        score += 0.2
    if neg:
        score -= 0.5
    score = max(0.0, min(1.0, score))
    return {
        "score": round(score, 2),
        "food_items": foods[:6],
        "free_stuff": stuff[:4],
        "negative_signal": neg,
    }


def llm_check(text: str) -> dict | None:
    """Ask Claude to double-check borderline posts. Returns None if unavailable."""
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=os.environ.get("FREEFOOD_MODEL", "claude-haiku-4-5"),
            max_tokens=200,
            messages=[{
                "role": "user",
                "content": (
                    "A college club posted the text below. Does the event offer FREE food "
                    "or free giveaways to attendees (not a paid fundraiser or bake sale)? "
                    'Reply with JSON only: {"free": true|false, "what": "short list of items"}\n\n'
                    f"POST:\n{text[:1500]}"
                ),
            }],
        )
        raw = msg.content[0].text
        return json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
    except Exception:
        return None


def classify(text: str, threshold: float = 0.5) -> dict:
    r = rule_score(text)
    if 0.25 <= r["score"] < 0.75:  # ambiguous -> let the LLM weigh in
        verdict = llm_check(text)
        if verdict is not None:
            r["llm"] = verdict
            r["score"] = max(r["score"], 0.8) if verdict.get("free") else min(r["score"], 0.2)
            if verdict.get("what"):
                r["llm_what"] = verdict["what"]
    r["has_free_food"] = r["score"] >= threshold
    return r
